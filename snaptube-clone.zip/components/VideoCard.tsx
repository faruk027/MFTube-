import React from 'react';
import { Download, MoreVertical } from 'lucide-react';
import { YouTubeVideo } from '../types';
import { parseDuration, formatViews } from '../services/youtubeService';

interface VideoCardProps {
  video: YouTubeVideo;
  onDownloadClick: (video: YouTubeVideo) => void;
  onPlayClick: (video: YouTubeVideo) => void;
}

const VideoCard: React.FC<VideoCardProps> = ({ video, onDownloadClick, onPlayClick }) => {
  const { snippet, contentDetails, statistics } = video;
  
  const duration = contentDetails ? parseDuration(contentDetails.duration) : '4:57';
  const views = statistics ? formatViews(statistics.viewCount) : '120K';

  return (
    <div className="flex flex-col bg-white mb-4 shadow-sm">
      {/* Thumbnail Container - Click to Play */}
      <div 
        className="relative w-full aspect-video cursor-pointer"
        onClick={() => onPlayClick(video)}
      >
        <img 
          src={snippet.thumbnails.high.url} 
          alt={snippet.title} 
          className="w-full h-full object-cover"
        />
        <div className="absolute bottom-2 right-2 bg-black bg-opacity-80 text-white text-xs px-1 rounded">
          {duration}
        </div>
      </div>

      {/* Info Container */}
      <div className="p-3 flex justify-between items-start">
        <div className="flex gap-3 flex-1" onClick={() => onPlayClick(video)}>
          {/* Channel Icon Placeholder */}
          <div className="w-10 h-10 rounded-full bg-gray-200 flex-shrink-0 overflow-hidden">
             <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${snippet.channelTitle}`} alt="channel" />
          </div>
          
          <div className="flex flex-col">
            <h3 className="text-sm font-medium line-clamp-2 text-gray-800 leading-tight mb-1">
              {snippet.title}
            </h3>
            <p className="text-xs text-gray-500">
              {snippet.channelTitle} • {views} views • {new Date(snippet.publishedAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onDownloadClick(video);
            }}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-full transition-colors"
          >
            <Download size={20} />
          </button>
          <button className="p-2 text-gray-600 hover:bg-gray-100 rounded-full">
            <MoreVertical size={20} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default VideoCard;