import React from 'react';
import { Home, Download, Settings, PlayCircle } from 'lucide-react';
import { Tab } from '../types';

interface BottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const getTabClass = (tab: Tab) => {
    return activeTab === tab 
      ? "text-yellow-500 flex flex-col items-center justify-center w-full h-full" 
      : "text-gray-400 hover:text-gray-600 flex flex-col items-center justify-center w-full h-full";
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 flex justify-between items-center px-2 z-40 pb-safe">
      <button className={getTabClass(Tab.HOME)} onClick={() => onTabChange(Tab.HOME)}>
        <Home size={24} />
        <span className="text-[10px] mt-1 font-medium">Home</span>
      </button>
      
      <button className={getTabClass(Tab.PLAYER)} onClick={() => onTabChange(Tab.PLAYER)}>
         <PlayCircle size={24} />
         <span className="text-[10px] mt-1 font-medium">Player</span>
      </button>

      <button className={getTabClass(Tab.DOWNLOADS)} onClick={() => onTabChange(Tab.DOWNLOADS)}>
        <Download size={24} />
        <span className="text-[10px] mt-1 font-medium">Downloads</span>
      </button>

      <button className={getTabClass(Tab.SETTINGS)} onClick={() => onTabChange(Tab.SETTINGS)}>
        <Settings size={24} />
        <span className="text-[10px] mt-1 font-medium">Settings</span>
      </button>
    </div>
  );
};

export default BottomNav;