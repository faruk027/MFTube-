import React from 'react';
import { X, Music, Video, Check } from 'lucide-react';
import { YouTubeVideo } from '../types';
import { AD_URL } from '../constants';

interface DownloadSheetProps {
  video: YouTubeVideo | null;
  onClose: () => void;
  onConfirmDownload: (format: string, resolution: string) => void;
}

const DownloadSheet: React.FC<DownloadSheetProps> = ({ video, onClose, onConfirmDownload }) => {
  if (!video) return null;

  const handleOptionClick = (type: 'audio' | 'video', quality: string) => {
    // Requirement: Visit Ad on download
    window.open(AD_URL, '_blank');
    onConfirmDownload(type === 'audio' ? quality : 'MP4', quality);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black bg-opacity-50 animate-fade-in">
      <div className="bg-white w-full max-w-md rounded-t-2xl overflow-hidden shadow-2xl animate-slide-up">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold text-gray-800">Download As</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-gray-100">
            <X size={24} className="text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 max-h-[70vh] overflow-y-auto">
          <div className="flex gap-3 mb-4">
             <img 
              src={video.snippet.thumbnails.medium.url} 
              className="w-24 h-16 object-cover rounded" 
              alt="thumbnail" 
            />
            <div className="flex-1 min-w-0">
               <p className="text-sm font-medium line-clamp-2">{video.snippet.title}</p>
               <p className="text-xs text-gray-500 mt-1">{video.snippet.channelTitle}</p>
            </div>
          </div>

          <div className="space-y-6">
            {/* Music Section */}
            <div>
              <div className="flex items-center gap-2 mb-2 text-yellow-500 font-medium">
                <Music size={18} />
                <span>Music</span>
              </div>
              <div className="grid grid-cols-1 gap-2">
                <button 
                  onClick={() => handleOptionClick('audio', 'MP3 160k')}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-yellow-50 active:bg-yellow-100 transition-colors"
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">MP3</span>
                    <span className="text-xs text-gray-500">160kbps</span>
                  </div>
                  <span className="text-xs text-gray-500">4.2MB</span>
                </button>
                <button 
                  onClick={() => handleOptionClick('audio', 'M4A 128k')}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-yellow-50 active:bg-yellow-100 transition-colors"
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">M4A</span>
                    <span className="text-xs text-gray-500">128kbps</span>
                  </div>
                  <span className="text-xs text-gray-500">3.8MB</span>
                </button>
              </div>
            </div>

            {/* Video Section */}
            <div>
              <div className="flex items-center gap-2 mb-2 text-blue-500 font-medium">
                <Video size={18} />
                <span>Video</span>
              </div>
              <div className="grid grid-cols-1 gap-2">
                 <button 
                  onClick={() => handleOptionClick('video', '1080p HD')}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-blue-50 active:bg-blue-100 transition-colors"
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">1080p HD</span>
                    <span className="text-xs text-gray-500">MP4</span>
                  </div>
                  <span className="text-xs text-gray-500">145MB</span>
                </button>
                <button 
                  onClick={() => handleOptionClick('video', '720p HD')}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-blue-50 active:bg-blue-100 transition-colors"
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">720p HD</span>
                    <span className="text-xs text-gray-500">MP4</span>
                  </div>
                  <span className="text-xs text-gray-500">85MB</span>
                </button>
                 <button 
                  onClick={() => handleOptionClick('video', '480p')}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-blue-50 active:bg-blue-100 transition-colors"
                >
                  <div className="flex flex-col items-start">
                    <span className="font-medium text-sm">480p</span>
                    <span className="text-xs text-gray-500">MP4</span>
                  </div>
                  <span className="text-xs text-gray-500">42MB</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DownloadSheet;