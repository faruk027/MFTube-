import React, { useState } from 'react';
import { HashRouter as Router } from 'react-router-dom';
import BottomNav from './components/BottomNav';
import Home from './pages/Home';
import Downloads from './pages/Downloads';
import Settings from './pages/Settings';
import Player from './pages/Player';
import DownloadSheet from './components/DownloadSheet';
import { Tab, YouTubeVideo, DownloadTask } from './types';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.HOME);
  const [downloads, setDownloads] = useState<DownloadTask[]>([]);
  const [playingVideo, setPlayingVideo] = useState<YouTubeVideo | null>(null);
  const [videoToDownload, setVideoToDownload] = useState<YouTubeVideo | null>(null);

  // Play Video Handler
  const handlePlayVideo = (video: YouTubeVideo) => {
    setPlayingVideo(video);
    setActiveTab(Tab.PLAYER);
  };

  // Open Download Sheet Handler
  const handleOpenDownloadSheet = (video: YouTubeVideo) => {
    setVideoToDownload(video);
  };

  // Confirm Download Handler
  const handleAddDownload = (format: string, quality: string) => {
    if (!videoToDownload) return;

    let taskFormat: 'MP3' | 'M4A' | '720p' | '1080p' | '480p' = 'MP3';

    if (format === 'MP4') {
        if (quality.includes('1080p')) taskFormat = '1080p';
        else if (quality.includes('720p')) taskFormat = '720p';
        else if (quality.includes('480p')) taskFormat = '480p';
        else taskFormat = '720p';
    } else {
        if (format.includes('M4A')) taskFormat = 'M4A';
        else taskFormat = 'MP3';
    }

    // Determine total size based on format
    let totalSizeMB = 10;
    switch (taskFormat) {
      case '1080p': totalSizeMB = 145; break;
      case '720p': totalSizeMB = 85; break;
      case '480p': totalSizeMB = 42; break;
      case 'M4A': totalSizeMB = 3.8; break;
      case 'MP3': totalSizeMB = 4.2; break;
    }

    const newTask: DownloadTask = {
      id: Math.random().toString(36).substr(2, 9),
      title: videoToDownload.snippet.title,
      thumbnail: videoToDownload.snippet.thumbnails.medium.url,
      format: taskFormat,
      progress: 0,
      status: 'downloading',
      size: `${totalSizeMB}MB`,
      speed: '0 KB/s',
      timeLeft: 'Calculating...'
    };

    setDownloads(prev => [newTask, ...prev]);

    // Simulate progress
    let downloadedMB = 0;
    const intervalTime = 500; // 500ms
    
    const interval = setInterval(() => {
      // Simulate speed: 1 MB/s to 4 MB/s (0.5 to 2 MB per 500ms)
      const chunk = 0.5 + Math.random() * 1.5; 
      downloadedMB += chunk;
      
      let progress = (downloadedMB / totalSizeMB) * 100;
      
      // Calculate speed and time left
      const speedMBps = chunk * (1000 / intervalTime); // MB per second
      const remainingMB = Math.max(0, totalSizeMB - downloadedMB);
      const secondsLeft = remainingMB / speedMBps;
      
      const speedStr = `${speedMBps.toFixed(1)} MB/s`;
      const timeStr = secondsLeft < 60 
        ? `${Math.ceil(secondsLeft)}s` 
        : `${Math.ceil(secondsLeft / 60)}m ${Math.ceil(secondsLeft % 60)}s`;

      if (progress >= 100) {
        progress = 100;
        clearInterval(interval);
        
        setDownloads(prev => prev.map(t => 
          t.id === newTask.id ? { 
            ...t, 
            progress: 100, 
            status: 'completed', 
            size: `${totalSizeMB}MB`,
            speed: '',
            timeLeft: ''
          } : t
        ));
      } else {
        setDownloads(prev => prev.map(t => 
          t.id === newTask.id ? { 
            ...t, 
            progress: progress,
            speed: speedStr,
            timeLeft: timeStr
          } : t
        ));
      }
    }, intervalTime);
  };

  const renderContent = () => {
    switch (activeTab) {
      case Tab.HOME:
        return <Home onDownload={handleOpenDownloadSheet} onPlay={handlePlayVideo} />;
      case Tab.PLAYER:
        return <Player video={playingVideo} onDownloadClick={handleOpenDownloadSheet} />;
      case Tab.DOWNLOADS:
        return <Downloads tasks={downloads} />;
      case Tab.SETTINGS:
        return <Settings />;
      default:
        return <Home onDownload={handleOpenDownloadSheet} onPlay={handlePlayVideo} />;
    }
  };

  return (
    <Router>
      <div className="max-w-md mx-auto bg-gray-50 min-h-screen relative shadow-2xl overflow-hidden">
        {renderContent()}
        <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
        
        {/* Global Download Sheet */}
        {videoToDownload && (
          <DownloadSheet 
            video={videoToDownload}
            onClose={() => setVideoToDownload(null)}
            onConfirmDownload={handleAddDownload}
          />
        )}
      </div>
    </Router>
  );
}

export default App;