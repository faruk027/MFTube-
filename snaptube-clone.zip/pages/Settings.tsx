import React, { useState, useEffect } from 'react';
import { ChevronRight, ArrowLeft } from 'lucide-react';
import { DEFAULT_API_KEY } from '../constants';

const Settings: React.FC = () => {
  const [apiKey, setApiKey] = useState('');
  const [wifiOnly, setWifiOnly] = useState(true);

  useEffect(() => {
    const savedKey = localStorage.getItem('yt_api_key');
    // Set to saved key, or default key if nothing is saved
    setApiKey(savedKey || DEFAULT_API_KEY);
  }, []);

  const handleSaveKey = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setApiKey(val);
    localStorage.setItem('yt_api_key', val);
  };

  return (
    <div className="bg-white min-h-screen pb-20">
      <div className="sticky top-0 bg-white z-10 px-4 py-4 flex items-center gap-4 border-b">
        <ArrowLeft size={24} className="text-gray-700" />
        <h1 className="text-xl font-medium text-gray-800">Download settings</h1>
      </div>

      <div className="pt-2">
        {/* Settings Groups */}
        <div className="px-4 py-4 hover:bg-gray-50 cursor-pointer">
          <p className="text-gray-700 text-base">Download path</p>
          <p className="text-gray-400 text-sm mt-0.5">/storage/emulated/0/snaptube/download</p>
           <div className="absolute right-4 mt-[-30px]">
             <ChevronRight size={20} className="text-gray-300" />
           </div>
        </div>

        <div className="px-4 py-4 hover:bg-gray-50 cursor-pointer border-t border-gray-100">
           <div className="flex justify-between items-center">
             <div>
                <p className="text-gray-700 text-base">Max download tasks</p>
                <p className="text-gray-400 text-xs mt-0.5">WIFI : 10 tasks | Mobile data : 2 tasks</p>
             </div>
             <ChevronRight size={20} className="text-gray-300" />
           </div>
        </div>

        <div className="px-4 py-4 hover:bg-gray-50 cursor-pointer border-t border-gray-100">
           <div className="flex justify-between items-center">
             <div>
                <p className="text-gray-700 text-base">Download Speed Limit</p>
                <p className="text-gray-400 text-xs mt-0.5">Unlimited</p>
             </div>
             <ChevronRight size={20} className="text-gray-300" />
           </div>
        </div>

        <div className="px-4 py-4 border-t border-gray-100 flex items-center justify-between">
           <div>
              <p className="text-gray-700 text-base">Download via mobile data</p>
              <p className="text-gray-400 text-xs mt-0.5">Media will be downloaded via data</p>
           </div>
           {/* Toggle Switch */}
           <button 
             onClick={() => setWifiOnly(!wifiOnly)}
             className={`w-10 h-5 rounded-full relative transition-colors ${wifiOnly ? 'bg-yellow-400' : 'bg-gray-300'}`}
           >
             <div className={`w-5 h-5 bg-white rounded-full shadow-md transform transition-transform ${wifiOnly ? 'translate-x-5' : 'translate-x-0'}`}></div>
           </button>
        </div>

        {/* API Key Section */}
        <div className="mt-6 px-4">
            <h2 className="text-sm font-bold text-gray-500 uppercase mb-2">System Config</h2>
            <div className="bg-gray-50 p-4 rounded-lg border">
                <label className="block text-sm font-medium text-gray-700 mb-1">YouTube API Key</label>
                <input 
                  type="text" 
                  value={apiKey}
                  onChange={handleSaveKey}
                  placeholder="Paste AIza... key here"
                  className="w-full text-sm p-2 border rounded focus:ring-2 focus:ring-yellow-400 outline-none font-mono"
                />
                <p className="text-xs text-gray-500 mt-2">
                    Required to fetch video data. Saved locally to your browser.
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;