import React, { useState } from 'react';
import { DownloadTask } from '../types';
import { PlayCircle, Music, Video, MoreVertical, FileAudio, FileVideo, Clock, Loader2 } from 'lucide-react';

interface DownloadsProps {
  tasks: DownloadTask[];
}

type FilterType = 'all' | 'music' | 'video';

const Downloads: React.FC<DownloadsProps> = ({ tasks }) => {
  const [filter, setFilter] = useState<FilterType>('all');

  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') return true;
    const isAudio = task.format.includes('MP3') || task.format.includes('M4A');
    return filter === 'music' ? isAudio : !isAudio;
  });

  return (
    <div className="bg-white min-h-screen pb-20">
      <div className="sticky top-0 bg-white z-10 shadow-sm">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-100">
           <h1 className="text-lg font-bold text-gray-800">My Files</h1>
           <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-full">{tasks.length} files</span>
        </div>
        
        {/* Tabs */}
        <div className="flex border-b border-gray-200">
          <button 
            onClick={() => setFilter('all')}
            className={`flex-1 py-3 text-sm font-medium relative ${filter === 'all' ? 'text-red-600' : 'text-gray-500'}`}
          >
            All
            {filter === 'all' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600"></div>}
          </button>
          <button 
             onClick={() => setFilter('music')}
             className={`flex-1 py-3 text-sm font-medium relative flex items-center justify-center gap-1 ${filter === 'music' ? 'text-red-600' : 'text-gray-500'}`}
          >
            <Music size={16} /> Music
            {filter === 'music' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600"></div>}
          </button>
          <button 
             onClick={() => setFilter('video')}
             className={`flex-1 py-3 text-sm font-medium relative flex items-center justify-center gap-1 ${filter === 'video' ? 'text-red-600' : 'text-gray-500'}`}
          >
            <Video size={16} /> Video
            {filter === 'video' && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-red-600"></div>}
          </button>
        </div>
      </div>

      {filteredTasks.length === 0 ? (
        <div className="flex flex-col items-center justify-center pt-32 text-gray-400">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            {filter === 'music' ? <Music size={40} className="opacity-30" /> : 
             filter === 'video' ? <Video size={40} className="opacity-30" /> :
             <PlayCircle size={40} className="opacity-30" />
            }
          </div>
          <p>No {filter !== 'all' ? filter : ''} downloads found</p>
          <p className="text-sm mt-1 opacity-70">Go to Home to find videos</p>
        </div>
      ) : (
        <div className="divide-y divide-gray-100">
          {filteredTasks.map((task) => (
            <div key={task.id} className="p-3 flex gap-3 hover:bg-gray-50 active:bg-gray-100 transition-colors cursor-pointer">
              {/* Thumbnail with Icon Overlay */}
              <div className="relative w-24 h-24 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                <img src={task.thumbnail} alt="thumb" className="w-full h-full object-cover" />
                <div className="absolute bottom-1 right-1 bg-black/60 p-1 rounded-md">
                   {task.format.includes('MP3') || task.format.includes('M4A') ? (
                     <FileAudio size={14} className="text-white" />
                   ) : (
                     <FileVideo size={14} className="text-white" />
                   )}
                </div>
                {task.status === 'downloading' && (
                  <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white backdrop-blur-[1px]">
                    <span className="text-sm font-bold">{Math.round(task.progress)}%</span>
                    <Loader2 size={16} className="animate-spin mt-1 opacity-80" />
                  </div>
                )}
              </div>
              
              <div className="flex-1 min-w-0 flex flex-col justify-center gap-1">
                <h4 className="text-sm font-medium text-gray-800 line-clamp-2 leading-tight">
                  {task.title}
                </h4>
                
                <div className="flex items-center gap-2 mt-1">
                   {task.status === 'downloading' ? (
                      <div className="w-full">
                         <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden mb-1.5">
                            <div 
                              className="h-full bg-red-500 transition-all duration-300"
                              style={{ width: `${task.progress}%` }}
                            />
                         </div>
                         <div className="flex justify-between items-center text-[10px] text-gray-500 font-medium">
                            <span className="flex items-center gap-1">
                               <Clock size={10} /> {task.timeLeft || 'Calculating...'}
                            </span>
                            <span>{task.speed || '0 MB/s'}</span>
                         </div>
                      </div>
                   ) : (
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <span className="bg-gray-100 px-1.5 py-0.5 rounded text-gray-600 font-medium">{task.format}</span>
                        <span>•</span>
                        <span>{task.size}</span>
                        <span>•</span>
                        <span className="text-green-600">Completed</span>
                      </div>
                   )}
                </div>
              </div>
              
              <button className="text-gray-400 p-2 hover:bg-gray-100 rounded-full h-fit self-center">
                <MoreVertical size={18} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Downloads;