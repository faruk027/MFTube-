import React, { useState, useEffect } from 'react';
import { Search, Youtube, Facebook, Instagram, Music, Gamepad2, Film, Newspaper, Flame } from 'lucide-react';
import VideoCard from '../components/VideoCard';
import { YouTubeVideo } from '../types';
import { searchVideos, getPopularVideos, getApiKey } from '../services/youtubeService';

interface HomeProps {
  onDownload: (video: YouTubeVideo) => void;
  onPlay: (video: YouTubeVideo) => void;
}

const CATEGORIES = [
  { id: 'all', label: 'For You' },
  { id: 'music', label: 'Music' },
  { id: 'trending', label: 'Trending' },
  { id: 'gaming', label: 'Gaming' },
  { id: 'movies', label: 'Movies' },
  { id: 'news', label: 'News' },
];

const QUICK_LINKS = [
  { name: 'YouTube', icon: <Youtube size={24} className="text-white" />, color: 'bg-red-600', url: 'https://youtube.com' },
  { name: 'Facebook', icon: <Facebook size={24} className="text-white" />, color: 'bg-blue-600', url: 'https://facebook.com' },
  { name: 'Instagram', icon: <Instagram size={24} className="text-white" />, color: 'bg-pink-600', url: 'https://instagram.com' },
  { name: 'TikTok', icon: <Music size={24} className="text-white" />, color: 'bg-black', url: 'https://tiktok.com' },
];

const Home: React.FC<HomeProps> = ({ onDownload, onPlay }) => {
  const [videos, setVideos] = useState<YouTubeVideo[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState('all');

  useEffect(() => {
    loadInitialVideos();
  }, []);

  const loadInitialVideos = async () => {
    await fetchVideosByCategory('all');
  };

  const fetchVideosByCategory = async (category: string) => {
    const key = getApiKey();
    if (!key) {
      setError("Please add your YouTube Data API Key in Settings.");
      return;
    }

    setLoading(true);
    setActiveCategory(category);
    setError(null);

    let results: YouTubeVideo[] = [];

    if (category === 'all' || category === 'trending') {
      results = await getPopularVideos();
    } else {
      results = await searchVideos(category);
    }

    if (results.length > 0) {
      setVideos(results);
    } else {
       // If popular fails or empty, fallback to search generic term to show something
       if (category === 'all') {
         const fallback = await searchVideos('new music video');
         setVideos(fallback);
       } else {
         setError("No videos found.");
       }
    }
    setLoading(false);
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    const results = await searchVideos(searchQuery);
    setVideos(results);
    setLoading(false);
  };

  return (
    <div className="pb-20 bg-gray-50 min-h-screen">
      {/* Search Header */}
      <div className="bg-red-600 px-4 py-3 sticky top-0 z-40 shadow-md">
        <form onSubmit={handleSearch} className="relative">
          <input
            type="text"
            placeholder="Search or enter URL"
            className="w-full bg-white text-gray-800 rounded-lg py-2.5 pl-10 pr-4 text-sm focus:outline-none shadow-inner"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
        </form>
      </div>

      {/* Quick Access Links */}
      <div className="bg-white pt-4 pb-2 px-4 mb-2">
         <div className="flex justify-between items-start mb-4">
            {QUICK_LINKS.map((link) => (
              <a 
                key={link.name} 
                href={link.url} 
                target="_blank" 
                rel="noreferrer"
                className="flex flex-col items-center gap-1 group"
              >
                 <div className={`w-12 h-12 rounded-full ${link.color} flex items-center justify-center shadow-md group-active:scale-95 transition-transform`}>
                    {link.icon}
                 </div>
                 <span className="text-xs text-gray-600 font-medium">{link.name}</span>
              </a>
            ))}
         </div>
         
         {/* Categories */}
         <div className="flex gap-2 overflow-x-auto no-scrollbar py-2 -mx-4 px-4 border-t border-gray-100">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => fetchVideosByCategory(cat.id)}
                className={`flex-shrink-0 px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  activeCategory === cat.id 
                    ? 'bg-red-100 text-red-600 border border-red-200' 
                    : 'bg-gray-100 text-gray-600 border border-transparent'
                }`}
              >
                {cat.label}
              </button>
            ))}
         </div>
      </div>

      {/* Content Feed */}
      <div className="">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20">
             <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
             <p className="mt-2 text-gray-500 text-sm">Loading videos...</p>
          </div>
        ) : error ? (
            <div className="p-8 text-center">
                 <p className="text-red-500 mb-2">{error}</p>
                 <p className="text-sm text-gray-500">Go to Settings to check API Key.</p>
            </div>
        ) : (
          videos.map((video, index) => (
            <VideoCard 
              key={typeof video.id === 'string' ? video.id : video.id.videoId || index} 
              video={video} 
              onDownloadClick={onDownload} 
              onPlayClick={onPlay}
            />
          ))
        )}
      </div>
    </div>
  );
};

export default Home;