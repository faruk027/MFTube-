import React, { useEffect, useRef, useState } from 'react';
import { YouTubeVideo } from '../types';
import { Download, Share2, ThumbsUp, Plus, Play, Pause, Volume2, VolumeX, Maximize, Minimize, ExternalLink, AlertCircle, RotateCcw, RotateCw, Loader2, List } from 'lucide-react';

interface PlayerProps {
  video: YouTubeVideo | null;
  onDownloadClick: (video: YouTubeVideo) => void;
}

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

// Helper to convert timestamp string to seconds
const timeToSeconds = (timeStr: string): number => {
  const parts = timeStr.split(':').map(part => parseInt(part, 10));
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  return 0;
};

const Player: React.FC<PlayerProps> = ({ video, onDownloadClick }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(true); // Start buffering by default
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(100);
  const [isMuted, setIsMuted] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [playerError, setPlayerError] = useState<number | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [seekFeedback, setSeekFeedback] = useState<'forward' | 'backward' | null>(null);
  const [chapters, setChapters] = useState<{time: string, title: string, seconds: number}[]>([]);
  
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const controlsTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastTapRef = useRef<{time: number, x: number} | null>(null);

  // Extract video ID safely
  const videoId = video ? (typeof video.id === 'string' ? video.id : video.id.videoId) : '';

  // Listen for fullscreen change
  useEffect(() => {
    const handleFullScreenChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullScreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullScreenChange);
  }, []);

  // Parse chapters from description
  useEffect(() => {
    if (video?.snippet?.description) {
      const lines = video.snippet.description.split('\n');
      // Regex to find timestamps like 0:00, 01:23, 1:02:30 at start of line
      const timeRegex = /(\d{1,2}:\d{2}(?::\d{2})?)/;
      const foundChapters: {time: string, title: string, seconds: number}[] = [];
      const seenSeconds = new Set<number>();

      lines.forEach(line => {
        const match = line.match(timeRegex);
        if (match) {
            const timeStr = match[1];
            const seconds = timeToSeconds(timeStr);
            
            // Check if this looks like a chapter line (timestamp + text)
            // Remove the timestamp and common separators
            let title = line.replace(timeStr, '').trim();
            title = title.replace(/^[-–—:.]+\s*/, ''); 
            
            if (title.length > 0 && !seenSeconds.has(seconds)) {
               foundChapters.push({ time: timeStr, title, seconds });
               seenSeconds.add(seconds);
            }
        }
      });
      
      // Sort by time
      foundChapters.sort((a,b) => a.seconds - b.seconds);
      setChapters(foundChapters);
    } else {
        setChapters([]);
    }
  }, [video]);

  // Initialize and Manage Player Lifecycle
  useEffect(() => {
    if (!videoId) return;

    // Reset state on new video
    setPlayerError(null);
    setProgress(0);
    setDuration(0);
    setIsPlaying(false);
    setIsBuffering(true);
    setShowControls(true);

    let playerInstance: any = null;

    const loadYoutubeAPI = () => {
      if (!window.YT) {
        const tag = document.createElement('script');
        tag.src = 'https://www.youtube.com/iframe_api';
        const firstScriptTag = document.getElementsByTagName('script')[0];
        firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);
        window.onYouTubeIframeAPIReady = initPlayer;
      } else {
        initPlayer();
      }
    };

    const initPlayer = () => {
      // Ensure the element exists
      if (!document.getElementById('youtube-player')) return;

      try {
        playerInstance = new window.YT.Player('youtube-player', {
          height: '100%',
          width: '100%',
          videoId: videoId,
          playerVars: {
            autoplay: 1,
            controls: 0, 
            modestbranding: 1,
            rel: 0,
            fs: 0,
            iv_load_policy: 3, 
            disablekb: 1, 
            enablejsapi: 1, // Important for API control
            origin: window.location.origin,
            playsinline: 1,
          },
          events: {
            onReady: onPlayerReady,
            onStateChange: onPlayerStateChange,
            onError: onPlayerError,
          },
        });
        playerRef.current = playerInstance;
      } catch (e) {
        console.error("Error initializing player", e);
      }
    };

    loadYoutubeAPI();

    return () => {
      stopProgressTracking();
      if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
      if (playerInstance && typeof playerInstance.destroy === 'function') {
        playerInstance.destroy();
      }
      playerRef.current = null;
    };
  }, [videoId]); // Re-run when videoId changes

  const onPlayerReady = (event: any) => {
    setDuration(event.target.getDuration());
    setVolume(event.target.getVolume());
    setIsMuted(event.target.isMuted());
    event.target.playVideo();
  };

  const onPlayerError = (event: any) => {
    console.error("YouTube Player Error Code:", event.data);
    setPlayerError(event.data);
    setIsPlaying(false);
    setIsBuffering(false);
    stopProgressTracking();
  };

  const onPlayerStateChange = (event: any) => {
    const state = event.data;
    // -1: unstarted, 0: ended, 1: playing, 2: paused, 3: buffering
    
    if (state === 1) { // Playing
      setIsPlaying(true);
      setIsBuffering(false);
      startProgressTracking();
      // Ensure duration is set
      if (playerRef.current) setDuration(playerRef.current.getDuration());
    } else if (state === 2) { // Paused
      setIsPlaying(false);
      setIsBuffering(false);
      stopProgressTracking();
    } else if (state === 3) { // Buffering
      setIsBuffering(true);
      setIsPlaying(false);
    } else if (state === 0) { // Ended
      setIsPlaying(false);
      setIsBuffering(false);
      stopProgressTracking();
      setProgress(0);
      setShowControls(true);
    }
  };

  const startProgressTracking = () => {
    stopProgressTracking();
    progressInterval.current = setInterval(() => {
      if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
        const current = playerRef.current.getCurrentTime();
        setProgress(current);
      }
    }, 500);
  };

  const stopProgressTracking = () => {
    if (progressInterval.current) clearInterval(progressInterval.current);
  };

  const togglePlay = () => {
    if (playerRef.current && typeof playerRef.current.playVideo === 'function') {
      if (isPlaying) {
        playerRef.current.pauseVideo();
      } else {
        playerRef.current.playVideo();
      }
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    setProgress(time);
    if (playerRef.current && typeof playerRef.current.seekTo === 'function') {
      playerRef.current.seekTo(time, true);
    }
  };

  const seekToChapter = (seconds: number) => {
    if (playerRef.current && typeof playerRef.current.seekTo === 'function') {
      playerRef.current.seekTo(seconds, true);
      setProgress(seconds);
      if (!isPlaying) {
         playerRef.current.playVideo();
      }
    }
  };

  const seekRelative = (seconds: number) => {
      if (playerRef.current && typeof playerRef.current.getCurrentTime === 'function') {
          const current = playerRef.current.getCurrentTime();
          const newTime = Math.max(0, Math.min(duration, current + seconds));
          playerRef.current.seekTo(newTime, true);
          setProgress(newTime);
          
          setSeekFeedback(seconds > 0 ? 'forward' : 'backward');
          setTimeout(() => setSeekFeedback(null), 600);
      }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const vol = parseInt(e.target.value);
    setVolume(vol);
    if (playerRef.current && typeof playerRef.current.setVolume === 'function') {
      playerRef.current.setVolume(vol);
      if (vol > 0 && isMuted) {
        playerRef.current.unMute();
        setIsMuted(false);
      }
    }
  };

  const toggleMute = () => {
    if (playerRef.current && typeof playerRef.current.mute === 'function') {
      if (isMuted) {
        playerRef.current.unMute();
        setIsMuted(false);
      } else {
        playerRef.current.mute();
        setIsMuted(true);
      }
    }
  };

  const toggleFullScreen = () => {
    if (!document.fullscreenElement) {
      if (containerRef.current) {
        containerRef.current.requestFullscreen().catch(err => {
          console.error(`Full-screen error: ${err.message}`);
        });
      }
    } else {
      if (document.exitFullscreen) document.exitFullscreen();
    }
  };

  const handleContainerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const now = Date.now();
    const width = e.currentTarget.offsetWidth;
    const x = e.nativeEvent.offsetX;
    
    if (lastTapRef.current && (now - lastTapRef.current.time) < 300) {
        // Double tap
        const leftZone = width * 0.35;
        const rightZone = width * 0.65;

        if (x < leftZone) {
            seekRelative(-10);
        } else if (x > rightZone) {
            seekRelative(10);
        } else {
            togglePlay();
        }
        lastTapRef.current = null;
    } else {
        // Single tap
        lastTapRef.current = { time: now, x };
        if (!playerError) {
             setShowControls(true);
             resetControlsTimeout();
        }
    }
  };

  const resetControlsTimeout = () => {
    if (controlsTimeout.current) clearTimeout(controlsTimeout.current);
    controlsTimeout.current = setTimeout(() => {
      if (isPlaying) setShowControls(false);
    }, 3000);
  };

  useEffect(() => {
     if (isPlaying) resetControlsTimeout();
  }, [isPlaying, showControls]);


  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const openInYoutube = () => {
      if (!videoId) return;
      window.open(`https://www.youtube.com/watch?v=${videoId}`, '_blank');
  };

  const currentChapterIndex = chapters.findLastIndex(c => c.seconds <= progress);

  if (!video) {
    return (
      <div className="flex flex-col items-center justify-center h-screen pb-20 text-gray-400 bg-white">
        <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
             <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[20px] border-l-gray-300 border-b-[10px] border-b-transparent ml-1"></div>
        </div>
        <p className="font-medium">No video selected</p>
        <p className="text-sm mt-1 opacity-70">Go to Home to select a video</p>
      </div>
    );
  }

  return (
    <div className="bg-white min-h-screen pb-20">
      {/* Video Player Container */}
      <div 
        ref={containerRef}
        className="sticky top-0 w-full aspect-video bg-black z-30 relative group overflow-hidden select-none"
        onClick={handleContainerClick}
        onMouseMove={() => { setShowControls(true); resetControlsTimeout(); }}
        onMouseLeave={() => isPlaying && setShowControls(false)}
      >
        {/* Key forces re-mount on video change, ensuring clean state */}
        <div key={videoId} id="youtube-player" className="w-full h-full pointer-events-none"></div>

        {/* Buffering Indicator */}
        {isBuffering && !playerError && (
             <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                  <div className="bg-black/50 p-4 rounded-full">
                      <Loader2 className="animate-spin text-white w-10 h-10" />
                  </div>
             </div>
        )}

        {/* Double Tap Feedback Overlay */}
        {seekFeedback && (
             <div className={`absolute inset-y-0 ${seekFeedback === 'forward' ? 'right-0 pr-10' : 'left-0 pl-10'} w-1/2 flex items-center ${seekFeedback === 'forward' ? 'justify-end' : 'justify-start'} pointer-events-none z-20`}>
                 <div className="bg-white/20 backdrop-blur-sm rounded-full p-4 flex flex-col items-center animate-ping-once">
                     {seekFeedback === 'forward' ? <RotateCw size={32} className="text-white" /> : <RotateCcw size={32} className="text-white" />}
                     <span className="text-white text-xs font-bold mt-1">10s</span>
                 </div>
             </div>
        )}

        {/* Error State Overlay */}
        {playerError && (
             <div className="absolute inset-0 bg-black flex flex-col items-center justify-center text-white z-50 p-6 text-center">
                 <AlertCircle size={48} className="text-red-500 mb-4" />
                 <h3 className="text-lg font-bold mb-2">Video Unavailable</h3>
                 <p className="text-sm text-gray-300 mb-6 max-w-[80%]">
                    {playerError === 150 || playerError === 101 
                       ? "Playback disabled by the video owner on this site." 
                       : "An error occurred while trying to play this video."}
                 </p>
                 <button 
                    onClick={openInYoutube}
                    className="flex items-center gap-2 bg-red-600 text-white px-6 py-2 rounded-full font-medium hover:bg-red-700 transition-colors"
                 >
                    <ExternalLink size={18} />
                    Open in YouTube
                 </button>
             </div>
        )}

        {/* Custom Overlay Controls */}
        {!playerError && (
          <div 
            className={`absolute inset-0 bg-black/40 flex flex-col justify-end transition-opacity duration-300 ${showControls || !isPlaying ? 'opacity-100' : 'opacity-0'}`}
          >
            {/* Center Play Button (only when paused and not buffering) */}
            {!isPlaying && !isBuffering && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <button 
                    onClick={(e) => { e.stopPropagation(); togglePlay(); }}
                    className="w-16 h-16 bg-black/60 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors pointer-events-auto transform hover:scale-105 backdrop-blur-sm"
                  >
                      <Play size={32} fill="currentColor" className="ml-1" />
                  </button>
                </div>
            )}

            {/* Bottom Bar */}
            <div 
              className="p-3 bg-gradient-to-t from-black/90 via-black/60 to-transparent text-white"
              onClick={(e) => e.stopPropagation()} // Prevent hiding when clicking controls
            >
                {/* Progress Bar */}
                <div className="flex items-center gap-3 mb-2 text-xs font-medium">
                    <span>{formatTime(progress)}</span>
                    <div className="flex-1 relative h-1 bg-white/30 rounded-full cursor-pointer group/slider py-2">
                        <input 
                          type="range" 
                          min="0" 
                          max={duration || 100} 
                          value={progress} 
                          onChange={handleSeek}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        />
                        <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 h-1 bg-white/30 rounded-full"></div>
                        <div 
                          className="h-1 bg-red-600 rounded-full relative top-1/2 -translate-y-1/2 pointer-events-none"
                          style={{ width: `${(progress / (duration || 1)) * 100}%` }}
                        >
                          <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-red-600 rounded-full scale-0 group-hover/slider:scale-100 transition-transform"></div>
                        </div>
                    </div>
                    <span>{formatTime(duration)}</span>
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                        <button onClick={togglePlay} className="hover:text-red-500 transition-colors">
                            {isPlaying ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" />}
                        </button>
                        
                        <div className="flex items-center gap-2 group/vol">
                            <button onClick={toggleMute} className="hover:text-gray-300">
                              {isMuted || volume === 0 ? <VolumeX size={20} /> : <Volume2 size={20} />}
                            </button>
                            <input 
                              type="range" 
                              min="0" 
                              max="100" 
                              value={isMuted ? 0 : volume}
                              onChange={handleVolumeChange}
                              className="w-20 h-1 bg-white/30 rounded-lg appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full hover:[&::-webkit-slider-thumb]:bg-red-500"
                            />
                        </div>
                    </div>

                    <div className="flex items-center gap-4">
                      <button onClick={toggleFullScreen} className="hover:text-gray-300">
                          {isFullScreen ? <Minimize size={20} /> : <Maximize size={20} />}
                      </button>
                    </div>
                </div>
            </div>
          </div>
        )}
      </div>

      {/* Info */}
      <div className="p-4">
        <h1 className="text-lg font-medium leading-tight text-gray-800 mb-2 line-clamp-2">
            {video.snippet.title}
        </h1>
        <div className="flex items-center text-xs text-gray-500 mb-5">
            <span>{video.statistics?.viewCount ? parseInt(video.statistics.viewCount).toLocaleString() : '120K'} views</span>
            <span className="mx-1">•</span>
            <span>{new Date(video.snippet.publishedAt).toLocaleDateString()}</span>
        </div>

        {/* Actions */}
        <div className="flex justify-between px-4 border-b pb-4 mb-4">
            <button className="flex flex-col items-center gap-1 text-gray-600 hover:text-gray-900">
                <ThumbsUp size={22} className="stroke-[1.5]" />
                <span className="text-xs">Like</span>
            </button>
            <button className="flex flex-col items-center gap-1 text-gray-600 hover:text-gray-900">
                <Share2 size={22} className="stroke-[1.5]" />
                <span className="text-xs">Share</span>
            </button>
             <button className="flex flex-col items-center gap-1 text-gray-600 hover:text-gray-900">
                <Plus size={22} className="stroke-[1.5]" />
                <span className="text-xs">Save</span>
            </button>
            <button 
                onClick={() => onDownloadClick(video)}
                className="flex flex-col items-center gap-1 text-gray-600 hover:text-gray-900"
            >
                <Download size={22} className="stroke-[1.5]" />
                <span className="text-xs">Download</span>
            </button>
        </div>

        {/* Channel */}
        <div className="flex items-center gap-3 mb-4">
             <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden">
                 <img src={`https://api.dicebear.com/7.x/initials/svg?seed=${video.snippet.channelTitle}`} alt="channel" />
             </div>
             <div>
                 <p className="font-medium text-sm text-gray-900">{video.snippet.channelTitle}</p>
                 <p className="text-xs text-gray-500">1.2M subscribers</p>
             </div>
             <button className="ml-auto bg-red-600 text-white text-xs font-bold px-4 py-2 rounded-full uppercase tracking-wide">
                 Subscribe
             </button>
        </div>

        {/* Chapters Section */}
        {chapters.length > 0 && (
          <div className="bg-white rounded-lg border border-gray-100 mb-4 overflow-hidden shadow-sm">
             <div className="px-3 py-2 bg-gray-50 border-b border-gray-100 flex items-center gap-2">
                <List size={16} className="text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Chapters</span>
             </div>
             <div className="max-h-48 overflow-y-auto">
               {chapters.map((chapter, idx) => (
                 <button
                   key={idx}
                   onClick={() => seekToChapter(chapter.seconds)}
                   className={`w-full text-left px-3 py-2 text-sm flex items-start gap-3 hover:bg-gray-50 transition-colors ${
                     currentChapterIndex === idx ? 'bg-red-50' : ''
                   }`}
                 >
                    <span className={`font-mono text-xs px-1.5 py-0.5 rounded ${
                       currentChapterIndex === idx ? 'bg-red-200 text-red-800' : 'bg-gray-200 text-gray-700'
                    }`}>
                        {chapter.time}
                    </span>
                    <span className={`line-clamp-1 ${currentChapterIndex === idx ? 'font-medium text-red-900' : 'text-gray-700'}`}>
                        {chapter.title}
                    </span>
                 </button>
               ))}
             </div>
          </div>
        )}

        {/* Description */}
        <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 whitespace-pre-wrap leading-relaxed">
            <p className="font-medium text-gray-800 mb-1">Description</p>
            {video.snippet.description || "No description available for this video."}
        </div>
      </div>
    </div>
  );
};

export default Player;