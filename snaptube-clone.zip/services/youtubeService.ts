import { YouTubeVideo } from '../types';
import { DEFAULT_API_KEY } from '../constants';

const BASE_URL = 'https://www.googleapis.com/youtube/v3';

export const getApiKey = (): string => {
  // Use localStorage key if available, otherwise fallback to the hardcoded default key
  return localStorage.getItem('yt_api_key') || DEFAULT_API_KEY;
};

export const searchVideos = async (query: string): Promise<YouTubeVideo[]> => {
  const apiKey = getApiKey();
  if (!apiKey) return [];

  try {
    const response = await fetch(
      `${BASE_URL}/search?part=snippet&maxResults=20&q=${encodeURIComponent(query)}&type=video&key=${apiKey}`
    );
    const data = await response.json();
    if (data.error) {
      console.error('YouTube API Error:', data.error);
      return [];
    }
    return data.items || [];
  } catch (error) {
    console.error('Fetch error:', error);
    return [];
  }
};

export const getPopularVideos = async (): Promise<YouTubeVideo[]> => {
  const apiKey = getApiKey();
  if (!apiKey) return [];

  try {
    const response = await fetch(
      `${BASE_URL}/videos?part=snippet,contentDetails,statistics&chart=mostPopular&regionCode=US&maxResults=20&key=${apiKey}`
    );
    const data = await response.json();
    if (data.error) {
      console.error('YouTube API Error:', data.error);
      return [];
    }
    return data.items || [];
  } catch (error) {
    console.error('Fetch error:', error);
    return [];
  }
};

export const parseDuration = (duration: string): string => {
  // ISO 8601 duration parser (simple version)
  const match = duration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
  if (!match) return '00:00';
  
  const hours = (match[1] || '').replace('H', '');
  const minutes = (match[2] || '').replace('M', '');
  const seconds = (match[3] || '').replace('S', '');

  if (hours) {
    return `${hours}:${minutes.padStart(2, '0')}:${seconds.padStart(2, '0')}`;
  }
  return `${minutes || '0'}:${seconds.padStart(2, '0')}`;
};

export const formatViews = (views: string): string => {
  const num = parseInt(views, 10);
  if (isNaN(num)) return '0';
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
};