export interface VideoSnippet {
  publishedAt: string;
  channelId: string;
  title: string;
  description: string;
  thumbnails: {
    medium: {
      url: string;
    };
    high: {
      url: string;
    };
  };
  channelTitle: string;
  liveBroadcastContent: string;
}

export interface VideoId {
  videoId: string;
}

export interface YouTubeVideo {
  id: VideoId | string; // Search returns object, videos endpoint returns string
  snippet: VideoSnippet;
  contentDetails?: {
    duration: string;
  };
  statistics?: {
    viewCount: string;
  };
}

export interface DownloadTask {
  id: string;
  title: string;
  thumbnail: string;
  format: 'MP3' | 'M4A' | '720p' | '1080p' | '480p';
  progress: number;
  status: 'pending' | 'downloading' | 'completed' | 'failed';
  size: string;
  timeLeft?: string;
  speed?: string;
}

export enum Tab {
  HOME = 'HOME',
  PLAYER = 'PLAYER',
  DOWNLOADS = 'DOWNLOADS',
  SETTINGS = 'SETTINGS',
}