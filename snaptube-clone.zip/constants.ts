export const AD_URL = "https://otieu.com/4/10101259";

// Using the key provided by the user as default
export const DEFAULT_API_KEY = "AIzaSyBU31pyAJIK5qJklGNFdaXOJFI9Kz1bYTI";